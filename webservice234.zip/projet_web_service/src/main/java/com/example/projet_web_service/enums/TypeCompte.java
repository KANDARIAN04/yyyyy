package com.example.projet_web_service.enums;

public enum TypeCompte {
COURANT, EPAGNE
}
