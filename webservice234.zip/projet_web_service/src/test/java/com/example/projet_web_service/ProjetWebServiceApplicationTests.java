package com.example.projet_web_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetWebServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
